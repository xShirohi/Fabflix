
public class RecaptchaConstants {
	
    public static final String SECRET_KEY ="6Ld40ZEUAAAAAPZKZ2XCNjmFkSzo6YnJ_ggCug2s";

}
