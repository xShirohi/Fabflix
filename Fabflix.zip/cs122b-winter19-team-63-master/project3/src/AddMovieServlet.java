import com.google.gson.JsonObject;

import javax.annotation.Resource;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.jasypt.util.password.PasswordEncryptor;
import org.jasypt.util.password.StrongPasswordEncryptor;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

/**
 * This class is declared as LoginServlet in web annotation, 
 * which is mapped to the URL pattern /api/login
 */
@WebServlet(name = "AddMovieServlet", urlPatterns = "/api/add_movie")
public class AddMovieServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Create a dataSource which registered in web.xml
    @Resource(name = "jdbc/moviedb")
    private DataSource dataSource;

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String title = request.getParameter("Movie Title");
        String year_release = request.getParameter("Year Released");
        int year = Integer.parseInt(year_release);
        String director = request.getParameter("Movie Director");
        String star = request.getParameter("Movie Star");
        String genre = request.getParameter("Movie Genre");

        boolean added = false;
        boolean exist = false;
        boolean negative = true;
        
        //response.setContentType("application/json"); // Response mime type
        try {
        // Get a connection from dataSource
        Connection dbcon = dataSource.getConnection();

        // Declare our statement
        System.out.println(year);
        if(year >= 0) {
	        negative = false;
	        	
	        String query = "SELECT * FROM movies m WHERE m.title = ? AND m.year = ? "
	        		+ "AND m.director = ?;";
	        
	        PreparedStatement statement = dbcon.prepareStatement(query);
	        statement.setString(1, title);
	        statement.setInt(2, year);
	        statement.setString(3, director);
	        
	        
	        // Perform the query
	        ResultSet rs = statement.executeQuery();
	        
	        while(rs.next()) {
	        	exist = true;
	        }
	        
	        if(!exist) {
	        	query = "CALL add_movie(?, ?, ?, ?, ?)";
	        	statement = dbcon.prepareStatement(query);
	            statement.setString(1, title);
	            statement.setInt(2, year);
	            statement.setString(3, director);
	            statement.setString(4, star);
	            statement.setString(5, genre);
	        	rs = statement.executeQuery();
	        	added = true;
	        }
	        
	
	        // set response status to 200 (OK)
	        //response.setStatus(200);
	
	        rs.close();
	        statement.close();
        }
        dbcon.close();
        } catch (Exception e) {
        	
			// write error message JSON object to output
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("errorMessage", e.getMessage());

			// set reponse status to 500 (Internal Server Error)
			//response.setStatus(500);

        }

        /**
         * This example only allows username/password to be anteater/123456
         * In real world projects, you should talk to the database to verify username/password
         */
        
        if (added) {
            JsonObject responseJsonObject = new JsonObject();
            responseJsonObject.addProperty("status", "success");
            responseJsonObject.addProperty("message", title + " has been successfully added!");

            response.getWriter().write(responseJsonObject.toString());
        } else {
            // Login fails
            JsonObject responseJsonObject = new JsonObject();
            responseJsonObject.addProperty("status", "fail");
            if(exist) {
            	responseJsonObject.addProperty("message", "This movie already exists!");
            }else {
            	responseJsonObject.addProperty("message", "Release year cannot be negative!");
            }

            response.getWriter().write(responseJsonObject.toString());
        }
    }
}
