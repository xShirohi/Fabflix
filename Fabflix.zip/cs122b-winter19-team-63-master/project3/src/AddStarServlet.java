import com.google.gson.JsonObject;

import javax.annotation.Resource;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.jasypt.util.password.PasswordEncryptor;
import org.jasypt.util.password.StrongPasswordEncryptor;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

/**
 * This class is declared as LoginServlet in web annotation, 
 * which is mapped to the URL pattern /api/login
 */
@WebServlet(name = "AddStarServlet", urlPatterns = "/api/add_star")
public class AddStarServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    // Create a dataSource which registered in web.xml
    @Resource(name = "jdbc/moviedb")
    private DataSource dataSource;

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String name = request.getParameter("Star Name");
        String birth = request.getParameter("Star Birth Year");
        System.out.println(birth + " " + name);
        boolean added = false;
        boolean exist = false;
        boolean negative = true;
        
        //response.setContentType("application/json"); // Response mime type
        try {
        // Get a connection from dataSource
        Connection dbcon = dataSource.getConnection();

        // Declare our statement
        String query = "";
        PreparedStatement statement = dbcon.prepareStatement(query);
        if(birth.isEmpty()) {
        	query += "SELECT * from stars where name = ?;";
        	statement = dbcon.prepareStatement(query);
        	statement.setString(1, name);
        }
        else {
        	if(Integer.parseInt(birth) >= 0) {
        		query += "CALL add_star(?, ?);";
        		added = true;
        		negative = false;
        		statement = dbcon.prepareStatement(query);
        		statement.setString(1, name);
        		statement.setInt(2, Integer.parseInt(birth));
        	}
        }

        // Perform the query
        ResultSet rs = statement.executeQuery();
        
        while(rs.next()) {
        	exist = true;
        }
        if(!exist) {
        	query = "CALL add_star(?, null);";
        	PreparedStatement statement2 = dbcon.prepareStatement(query);
        	statement2.setString(1, name);
        	ResultSet rs2 = statement.executeQuery();
        	added = true;
            rs2.close();
            statement2.close();
        }
        

        // set response status to 200 (OK)
        //response.setStatus(200);

        rs.close();
        statement.close();
dbcon.close();
        } catch (Exception e) {
        	
			// write error message JSON object to output
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("errorMessage", e.getMessage());

			// set reponse status to 500 (Internal Server Error)
			//response.setStatus(500);

        }

        /**
         * This example only allows username/password to be anteater/123456
         * In real world projects, you should talk to the database to verify username/password
         */
        
        if (added) {
            JsonObject responseJsonObject = new JsonObject();
            responseJsonObject.addProperty("status", "success");
            responseJsonObject.addProperty("message", name + " has been successfully added!");

            response.getWriter().write(responseJsonObject.toString());
        } else {
            // Login fails
            JsonObject responseJsonObject = new JsonObject();
            responseJsonObject.addProperty("status", "fail");
            if(exist) {
            	responseJsonObject.addProperty("message", "Star " + name + " already exists!");
            }else {
            	responseJsonObject.addProperty("message", "Birth year cannot be negative!");
            }

            response.getWriter().write(responseJsonObject.toString());
        }
    }
}
