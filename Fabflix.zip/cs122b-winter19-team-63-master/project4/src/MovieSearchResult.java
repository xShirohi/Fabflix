	import com.google.gson.JsonArray;
	import com.google.gson.JsonObject;
	
	import javax.annotation.Resource;
	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.sql.DataSource;
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.sql.Connection;
	import java.sql.ResultSet;
	import java.sql.PreparedStatement;
	;
	
	// Declaring a WebServlet called MovieServlet, which maps to url "/api/movies"
	@WebServlet(name = "MovieSearchResult", urlPatterns = "/api/movie_result")
	public class MovieSearchResult extends HttpServlet {
	    private static final long serialVersionUID = 1L;
	
	    // Create a dataSource which registered in web.xml
	    @Resource(name = "jdbc/moviedb")
	    private DataSource dataSource;
	
	    /**
	     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	     */
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	        response.setContentType("application/json"); // Response mime type
	
	        String title = request.getParameter("query"); //grab query for title)
	        System.out.println("this is title: " + title);
	        String words[] = title.split(" ", 0);
	        String title_query = "";
	        for(String word: words) {
	        	title_query += "+" + word + "* ";
	        }
	        title_query = title_query.substring(0, title_query.length() - 1); // create to prefix fulltext search such as if query is 'wonder woman' title_query will be 'wonder* woman*'
	        System.out.println(title_query);
			
			String page = request.getParameter("page"); // grab page number
			String limit = request.getParameter("limit"); // // gran n listings to view per page
			//calculate offset based on N listings x page number 
			int offset = Integer.parseInt(limit) * Integer.parseInt(page); // calculate offset based on page and limit
			offset = offset - Integer.parseInt(limit);
			
			//figure out if sort is by title or rating 
			String sortby = request.getParameter("sortby");
			String sorttype = "";
			if(sortby.startsWith("t")) {sorttype = "m.title";} else{sorttype = "r.rating";};
			sortby = sortby.substring(1);
			
	        PrintWriter out = response.getWriter();
	        try {
	            // Get a connection from dataSource
	            Connection dbcon = dataSource.getConnection();
	
				String query = "SELECT m.id, m.title, m.year, m.director, r.rating, "
						+ "group_concat(distinct g.name order by g.name) as genre, "
						+ "group_concat(distinct s.name) as star, "
						+ "group_concat(distinct sm.starId) as starId "
						+ "FROM (SELECT * FROM movies WHERE MATCH (title) "
						+ "AGAINST (? IN BOOLEAN MODE)) as m, "
						+ "genres g, genres_in_movies gm, stars_in_movies sm , "
						+ "stars s, ratings r WHERE m.id = gm.movieId and m.id = sm.movieId "
						+ "and r.movieId = m.id and g.id = gm.genreId and s.id = sm.starId "
						+ "group by m.id, r.rating order by " + sorttype + " " + sortby + " "
						+ "limit ? offset ?;";

					
	            // Declare our statement
	            //String query = "SELECT * FROM movies WHERE MATCH (title) AGAINST (? "
	            //		+ "IN BOOLEAN MODE);";
				
	            PreparedStatement ps = dbcon.prepareStatement(query);
	            ps.setString(1, title_query);
				ps.setInt(2, Integer.parseInt(limit));
				ps.setInt(3, offset); //offNum is int version of offset
				
	            System.out.println("reach here " + ps.toString());
	            // Perform the query
	            ResultSet rs = ps.executeQuery();
	
	            JsonArray jsonArray = new JsonArray();
	            // Iterate through each row of rs
	            //"value": "Superman", "data": { "heroID": 101 } }
	            while (rs.next()) {
	                String movie_id = rs.getString("id");
	                String movie_name = rs.getString("title");
	                String movie_year = rs.getString("year");
	                String movie_director = rs.getString("director");
	                String genre_name = rs.getString("genre");
	                String star_name = rs.getString("star");
	                String star_id = rs.getString("starId");
	                String rating = rs.getString("rating");
	
	                // Create a JsonObject based on the data we retrieve from rs
	                JsonObject jsonObject = new JsonObject();
	                jsonObject.addProperty("movie_id", movie_id);
	                jsonObject.addProperty("movie_name", movie_name);
	                jsonObject.addProperty("movie_year", movie_year);
	                jsonObject.addProperty("director", movie_director);
	                jsonObject.addProperty("genre_name", genre_name);
	                jsonObject.addProperty("star_name", star_name);
	                jsonObject.addProperty("star_id", star_id);
	                jsonObject.addProperty("rating", rating);
	                jsonArray.add(jsonObject);
	            }
	            
	            // write JSON string to output
	            out.write(jsonArray.toString());
	            // set response status to 200 (OK)
	            response.setStatus(200);
	
	            rs.close();
	            ps.close();
	            dbcon.close();
	        } catch (Exception e) {
	        	
				// write error message JSON object to output
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("errorMessage", e.getMessage());
				out.write(jsonObject.toString());
	
				// set reponse status to 500 (Internal Server Error)
				response.setStatus(500);
	
	        }
	        out.close();
	
	    }
	}
