import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

// Declaring a WebServlet called SingleMovieServlet, which maps to url "/api/single-movie"
@WebServlet(name = "SingleMovieServlet", urlPatterns = "/api/single-movie")
public class SingleMovieServlet extends HttpServlet {
	private static final long serialVersionUID = 2L;

	// Create a dataSource which registered in web.xml
	@Resource(name = "jdbc/moviedb")
	private DataSource dataSource;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("application/json"); // Response mime type

		// Retrieve parameter id from url request.
		String id = request.getParameter("id");
		System.out.println(id);

		// Output stream to STDOUT
		PrintWriter out = response.getWriter();

		try {
			// Get a connection from dataSource
			Connection dbcon = dataSource.getConnection();

			// Construct a query with parameter represented by "?"
			String query = "SELECT m.id, m.title, m.year, m.director, "
					+ "group_concat(distinct g.name order by g.name) as genre, "
					+ "group_concat(distinct s.name) as star, "
					+ "r.rating, group_concat(distinct sm.starId) as starId "
					+ "FROM movies m, genres g, ratings r, genres_in_movies gm, "
					+ "stars_in_movies sm , stars s WHERE m.id = ? and m.id = gm.movieId "
					+ "and m.id = r.movieId and m.id = sm.movieId and g.id = gm.genreId "
					+ "and s.id = sm.starId group by m.id, r.rating;";
			// Declare our statement
			PreparedStatement statement = dbcon.prepareStatement(query);

			// Set the parameter represented by "?" in the query to the id we get from url,
			// num 1 indicates the first "?" in the query
			statement.setString(1, id);
			System.out.println(statement.toString());
			// Perform the query
			ResultSet rs = statement.executeQuery();
			JsonArray jsonArray = new JsonArray();
			if(!rs.next()) {
				query = "SELECT m.id, m.title, m.year, m.director, "
						+ "group_concat(distinct g.name order by g.name) as genre, "
						+ "group_concat(distinct s.name) as star, "
						+ "group_concat(distinct sm.starId) as starId "
						+ "FROM movies m, genres g, genres_in_movies gm, "
						+ "stars_in_movies sm , stars s WHERE m.id = ? "
						+ "and m.id = gm.movieId and m.id = sm.movieId "
						+ "and g.id = gm.genreId and s.id = sm.starId group by m.id;";
				statement = dbcon.prepareStatement(query);
				statement.setString(1, id);
				rs = statement.executeQuery();
				// Iterate through each row of rs
	            while (rs.next()) {
	            	System.out.println("reach");
	                String movie_id = rs.getString("id");
	                String movie_name = rs.getString("title");
	                String movie_year = rs.getString("year");
	                String movie_director = rs.getString("director");
	                String genre_name = rs.getString("genre");
	                String star_name = rs.getString("star");
	                String rating = "Unrated";
	                String star_id = rs.getString("starId");
	
	                // Create a JsonObject based on the data we retrieve from rs
	                JsonObject jsonObject = new JsonObject();
	                jsonObject.addProperty("movie_id", movie_id);
	                jsonObject.addProperty("movie_name", movie_name);
	                jsonObject.addProperty("movie_year", movie_year);
	                jsonObject.addProperty("director", movie_director);
	                jsonObject.addProperty("genre_name", genre_name);
	                jsonObject.addProperty("star_name", star_name);
	                jsonObject.addProperty("rating", rating);
	                jsonObject.addProperty("star_id", star_id);
	                
	                jsonArray.add(jsonObject);
	            }
			}
			else {
	
				// Iterate through each row of rs

	            	System.out.println("reach");
	                String movie_id = rs.getString("id");
	                String movie_name = rs.getString("title");
	                String movie_year = rs.getString("year");
	                String movie_director = rs.getString("director");
	                String genre_name = rs.getString("genre");
	                String star_name = rs.getString("star");
	                String rating = rs.getString("rating");
	                String star_id = rs.getString("starId");
	
	                // Create a JsonObject based on the data we retrieve from rs
	                JsonObject jsonObject = new JsonObject();
	                jsonObject.addProperty("movie_id", movie_id);
	                jsonObject.addProperty("movie_name", movie_name);
	                jsonObject.addProperty("movie_year", movie_year);
	                jsonObject.addProperty("director", movie_director);
	                jsonObject.addProperty("genre_name", genre_name);
	                jsonObject.addProperty("star_name", star_name);
	                jsonObject.addProperty("rating", rating);
	                jsonObject.addProperty("star_id", star_id);
	                
	                jsonArray.add(jsonObject);
	         
            }
			
            // write JSON string to output
            out.write(jsonArray.toString());
            // set response status to 200 (OK)
            response.setStatus(200);

			rs.close();
			statement.close();
			dbcon.close();
		} catch (Exception e) {
			// write error message JSON object to output
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("errorMessage", e.getMessage());
			out.write(jsonObject.toString());

			// set response status to 500 (Internal Server Error)
			response.setStatus(500);
		}
		out.close();

	}

}
