package edu.uci.ics.fabflixmobile;

import java.util.ArrayList;

public class Movies {
    private String title;
    private String director;
    private String year;
    private String genres;
    private String actors;

    public Movies(String title, String year, String director, String genres, String actors){
        this.title = title;
        this.director = director;
        this.year = year;
        this.genres = genres;
        this.actors = actors;
    }

    public String getTitle(){return title;}
    public String getDirector(){return director;}
    public String getYear(){return  year;}
    public String getGenres(){ return genres;}
    public String getActors(){return actors;}


}
