package edu.uci.ics.fabflixmobile;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GreenActivity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_green);

        Bundle bundle = getIntent().getExtras();

        String toDisplay = bundle.getString("title");
        String data = bundle.getString("jsonArray");
        try {
            JSONArray dt = new JSONArray(data);
            for(int x = 0; x < dt.length(); x++){
                JSONObject row = dt.getJSONObject(x);
                if (row.getString("movie_name").equals(toDisplay)){
                    ((TextView) findViewById(R.id.title)).setText(row.getString("movie_name"));
                    ((TextView) findViewById(R.id.year)).setText(row.getString("movie_year"));
                    ((TextView) findViewById(R.id.director)).setText(row.getString("director"));
                    ((TextView) findViewById(R.id.genres)).setText(row.getString("genre_name"));
                    ((TextView) findViewById(R.id.actors)).setText(row.getString("star_name"));
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }




}
