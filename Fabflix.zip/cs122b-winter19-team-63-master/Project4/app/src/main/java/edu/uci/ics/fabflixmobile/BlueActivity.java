package edu.uci.ics.fabflixmobile;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BlueActivity extends ActionBarActivity {

    static String page = "1";
    static String query = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blue);




    }

    public void connectToMovie(View view) {

        // no user is logged in, so we must connect to the server

        // Use the same network queue across our application
        final RequestQueue queue = NetworkManager.sharedManager(this).queue;

        // 10.0.2.2 is the host machine when running the android emulator

        query = ((EditText) findViewById(R.id.search)).getText().toString();
        final StringRequest movieRequest = new StringRequest(Request.Method.GET, "https://174.77.33.152:8443/project1/api/movie_result?query="+query+"&page="+page+"&limit=10&sortby=tasc",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray rs = new JSONArray(response);
                            Log.d("movie.success", response);
                            displayList(rs);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Log.d("movie.success", response);

                        // Add the request to the RequestQueue.

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Log.d("movie.error", error.toString());
                    }
                }
        );
        // !important: queue.add is where the login request is actually sent
        queue.add(movieRequest);

    }

    public void displayList(JSONArray rs){
        ArrayList<Movies> movies = new ArrayList<>();

        for(int x = 0; x < rs.length(); x++){
            JSONObject row = new JSONObject();
            try {
                row = rs.getJSONObject(x);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            try {
                Log.d("movie_name.success", row.getString("movie_name"));
                Log.d("movie_id.success", row.getString("movie_id"));
                Movies mov = new Movies(row.getString("movie_name"),row.getString("movie_year"), row.getString("director"), row.getString("genre_name"), row.getString("star_name"));
                movies.add(mov);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        MovieListViewAdapter adapter = new MovieListViewAdapter(movies, BlueActivity.this);

        ListView listView = (ListView)findViewById(R.id.list);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Movies movie = movies.get(position);
                Intent goIntent = new Intent(BlueActivity.this, GreenActivity.class);
                goIntent.putExtra("jsonArray", rs.toString());
                goIntent.putExtra("title", movie.getTitle());
                startActivity(goIntent);
            }
        });
    }


    public void nextPage(View view){
        // no user is logged in, so we must connect to the server

        // Use the same network queue across our application
        final RequestQueue queue = NetworkManager.sharedManager(this).queue;

        // 10.0.2.2 is the host machine when running the android emulator

        page = Integer.toString(Integer.parseInt(page) + 1);
        final StringRequest movieRequest = new StringRequest(Request.Method.GET, "https://174.77.33.152:8443/project1/api/movie_result?query="+query+"&page="+page+"&limit=10&sortby=tasc",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray rs = new JSONArray(response);
                            Log.d("movie.success", response);
                            displayList(rs);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Log.d("movie.success", response);

                        // Add the request to the RequestQueue.

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Log.d("movie.error", error.toString());
                    }
                }
        );
        // !important: queue.add is where the login request is actually sent
        queue.add(movieRequest);

    }

    public void prevPage(View view){
        final RequestQueue queue = NetworkManager.sharedManager(this).queue;

        // 10.0.2.2 is the host machine when running the android emulator
        if (page.equals("1"))
            return;
        page = Integer.toString(Integer.parseInt(page) - 1);
        final StringRequest movieRequest = new StringRequest(Request.Method.GET, "https://174.77.33.152:8443/project1/api/movie_result?query="+query+"&page="+page+"&limit=10&sortby=tasc",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONArray rs = new JSONArray(response);
                            Log.d("movie.success", response);
                            displayList(rs);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                        Log.d("movie.success", response);

                        // Add the request to the RequestQueue.

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Log.d("movie.error", error.toString());
                    }
                }
        );
        // !important: queue.add is where the login request is actually sent
        queue.add(movieRequest);
    }
}
