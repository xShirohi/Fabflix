/**
 * This example is following frontend and backend separation.
 *
 * Before this .js is loaded, the html skeleton is created.
 *
 * This .js performs two steps:
 *      1. Use jQuery to talk to backend API to get the json data.
 *      2. Populate the data to correct html elements.
 */


/**
 * Handles the data returned by the API, read the jsonObject and populate data into html elements
 * @param resultData jsonObject
 */
function handleResult(resultData) {

    console.log("handleResult: populating movie info from resultData");

    // populate the movie info h3
    // find the empty h3 body by id "movie_info"
    //let movieInfoElement = jQuery("#movie_info");

    // append two html <p> created to the h3 body, which will refresh the page
    //movieInfoElement.append("<p>Movie Name: " + resultData[0]["movie_name"] + "</p>" +
    //    "<p>Date Of Birth: " + resultData[0]["movie_dob"] + "</p>");

    console.log("handleResult: populating movie table from resultData");

    // Populate the movie table
    // Find the empty table body by id "movie_table_body"
    let movieTableBodyElement = jQuery("#movie_table_body");
    console.log(resultData);
    var x = 0;
    var i = 0;
    var cur;
    var placehold;
    var genre_check = [];
    var star_check = [];
    // Concatenate the html tags with resultData jsonObject to create table rows
    	//cur = resultData[x]["movie_id"];
        // Concatenate the html tags with resultData jsonObject
        //let rowHTML = "";
        //rowHTML += "<tr>";
        //rowHTML += "<th>" + resultData[x]["movie_name"] + "</th>";
    	//rowHTML += "<th>" + resultData[x]["movie_year"] + "</th>";
    	//rowHTML += "<th>" + resultData[x]["director"] + "</th>";
    	//rowHTML += "<th>" + resultData[x]["rating"] + "</th>";
    	//rowHTML += "<th>" + resultData[x]["genre_name"] + "</th>";
    	//rowHTML += "<th>" + resultData[x]["star_name"] + "</th>";
    	
        //rowHTML += "<th>";
        //placehold = "<th>";

        for (let i = 0; i < resultData.length; i++){ 
        	//console.log(resultData[i]["movie_name"]);
        	let rowHTML = "";
        	rowHTML += "<tr>";
        	rowHTML += "<th>" + '<a href="single-movie.html?id=' 
        	+ resultData[i]['movie_id'] + '">' + resultData[i]["movie_name"] + "</th>";
        	rowHTML += "<th>" + resultData[i]["movie_year"] + "</th>";
        	rowHTML += "<th>" + resultData[i]["director"] + "</th>";
        	rowHTML += "<th>" + resultData[i]["rating"] + "</th>";
        	//parse genre
        	var genres = resultData[i]["genre_name"];
        	genres = genres.split(",");
        	rowHTML += "<th>";
        	for(let x = 0; x < genres.length; x++){
        		var genre = "<a class=\"button\" href=\"browse-genre.html?genre="
            	+ genres[x] + "&page=1&limit=10&offset=0&sortby=rdesc" + "\"" 
            	+ ">" + genres[x] + "</a>, ";
        		rowHTML+= genre;
        	}
        	rowHTML = rowHTML.slice(0, -2) + "</th>";
        	//parse stars
        	var stars = resultData[i]["star_name"];
        	stars = stars.split(",");
        	var star_ids = resultData[i]["star_id"];
        	star_ids = star_ids.split(",");
        	rowHTML += "<th>";
        	for(let x = 0; x < stars.length; x++){
        		var star = '<a href="single-star.html?id='
            	+ star_ids[x] + '"' + ">" + stars[x] + "</a>, ";
        		rowHTML+= star;
        	}
        	rowHTML = rowHTML.slice(0, -2) + "</th>";
        	rowHTML += "</tr>";
        	movieTableBodyElement.append(rowHTML);
        }

        //rowHTML += "</th>";
        //rowHTML += rowHTML.substr(0, rowHTML.length -2) + "</th>";
        
        //rowHTML += "</tr>";

        // Append the row created to the table body, which will refresh the page
        //movieTableBodyElement.append(rowHTML);
}
let page = 1;
let limit = 20;
let offset = 0;
let sortby = "tasc";
var searchfor;
var title;
var year;
var director;
var star;

function search(){
	searchfor = document.getElementById('searchfor').value;
	title = $("#title").prop('checked');
	year = $("#year").prop('checked');
	director = $("#director").prop('checked');
	star = $("#star").prop('checked');	

	console.log(searchfor);
	console.log(title);
	
	var link = "index.html?title=" + title +
	   "&year=" + year + "&limit=" + limit +
	   "&offset=" + offset + "&sortby=" + sortby +
	   "&director=" + director + "&star=" + star +
	   "&searchfor=" + searchfor + "&page=" + page;
	
	console.log(link);
	window.location.href = link;
}

function linkupd(){
	link = link = "index.html?title=" + title +
	   "&year=" + year + "&limit=" + limit +
	   "&offset=" + offset + "&sortby=" + sortby +
	   "&director=" + director + "&star=" + star +
	   "&searchfor=" + searchfor + "&page=" + page;
	window.location.href = link;

	console.log(link);
}

function titsort(){
	if (sortby == "tasc")
		sortby = "tdesc";
	else
		sortby = "tasc";
	linkupd();
}

function rsort(){
	if (sortby == "rasc")
		sortby = "rdesc";
	else
		sortby = "rasc";
	linkupd();
}

function nextPage(){
	offset = limit * page;
	page++;
	linkupd();
}

function prevPage(){
	if (page > 1){
		page--;
		offset = (limit*page)-limit;
		linkupd();
	}
}

function changeLimit(){
	limit = document.getElementById('newlim').value;
	linkupd();
	console.log(limit);
}

$("#tasc").click((event) => titsort());
$("#tdesc").click((event) => titsort());
$("#rasc").click((event) => rsort());
$("#rdesc").click((event) => rsort());
$("#next").click((event) => nextPage());
$("#prev").click((event) => prevPage());
/**
 * Once this .js is loaded, following scripts will be executed by the browser
 */

// Makes the HTTP GET request and registers on success callback function handleMovieResult
jQuery.ajax({
    dataType: "json", // Setting return data type
    method: "GET", // Setting request method
    url: "api/movies", // Setting request url, which is mapped by MoviesServlet in Movies.java
    success: (resultData) => handleResult(resultData) // Setting callback function to handle data returned successfully by the MoviesServlet
});