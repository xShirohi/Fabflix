/**
 * Handle the data returned by IndexServlet
 * @param resultDataString jsonObject, consists of session info
 */
var add;
var remove;
var checkout;
var ccid;
var fname;
var lname;
var exp;


/**
 * Handle the items in item list 
 * @param resultDataString jsonObject, needs to be parsed to html 
 */
function addItem(item) {
	$.get(
	        "api/shoppingcart?add=" + item
	    );
}

function removeItem(item){
	$.get(
	        "api/shoppingcart?remove=" + item
	    );
}

/**
 * Submit form content with POST method
 * @param cartEvent
 */
function handleCheckout() {
	var fname = document.getElementById('fname').value;
	var lname = document.getElementById('lname').value;
	var ccid = document.getElementById('ccid').value;
	var date = document.getElementById('date').value;

    jQuery.ajax({
        dataType: "json", // Setting return data type
        method: "GET", // Setting request method
        url: "api/shoppingcart", // Setting request url, which is mapped by MoviesServlet in Movies.java
        data: {'fname' : fname, 
               'lname' : lname, 
               'ccid' : ccid, 
               'exp' : date
               },
        success: (resultData) => checkout(resultData) // Setting callback function to handle data returned successfully by the MoviesServlet
    });
}

function checkout(result){
	var popup = document.getElementById("myPopup");
	if (result[0]["checkedout"] == "t")
		popup.classList.toggle("show");
}


// Bind the submit action of the form to a event handler function