/**
 * This example is following frontend and backend separation.
 *
 * Before this .js is loaded, the html skeleton is created.
 *
 * This .js performs two steps:
 *      1. Use jQuery to talk to backend API to get the json data.
 *      2. Populate the data to correct html elements.
 */


/**
 * Handles the data returned by the API, read the jsonObject and populate data into html elements
 * @param resultData jsonObject
 */
function handleGenreResult(resultData) {
    console.log("handleMovieResult: populating movie table from resultData");

    // Populate the movie table
    // Find the empty table body by id "movie_table_body"
    let genreBodyElement = jQuery("#modalGenreBody");
    genreBodyElement.append("<b>Genre</b><br>");
    for (let i = 0; i < resultData.length; i++){
    	var genre = resultData[i]["genre_name"];
    	var code = "<a class=\"button\" href=\"browse-genre.html?genre=" + genre + //"\">" + genre + "</a>, ";
    	"&page=1&limit=10&offset=0&sortby=rdesc" + "\"" + ">" + genre + "</a>, ";
    	if(i == resultData.length - 1){
    		code = code.slice(0, -2);
    	}
    	genreBodyElement.append(code);
    }
    
    
    genreBodyElement.append("<br><br><b>Movie Starting With Letter</b><br>");
    for(let i = 65; i < 91; i++){
    	var letter = String.fromCharCode(i);
    	var code = "<a class=\"button\" href=\"browse-letter.html?letter=" + letter + //"\">" + genre + "</a>, ";
    	"&page=1&limit=10&offset=0&sortby=rdesc" + "\"" + ">" + letter + "</a>, ";
    	if(i == 90){
    		code = code.slice(0, -2);
    	}
    	genreBodyElement.append(code);
    }
}


/**
 * Once this .js is loaded, following scripts will be executed by the browser
 */

// Makes the HTTP GET request and registers on success callback function handleMovieResult
jQuery.ajax({
    dataType: "json", // Setting return data type
    method: "GET", // Setting request method
    url: "api/browseby", // Setting request url, which is mapped by MoviesServlet in Movies.java
    success: (resultData) => handleGenreResult(resultData) // Setting callback function to handle data returned successfully by the MoviesServlet
});