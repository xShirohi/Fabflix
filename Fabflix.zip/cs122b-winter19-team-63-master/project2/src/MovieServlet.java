import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;


// Declaring a WebServlet called MovieServlet, which maps to url "/api/movies"
@WebServlet(name = "MovieServlet", urlPatterns = "/api/movies")
public class MovieServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Create a dataSource which registered in web.xml
    @Resource(name = "jdbc/moviedb")
    private DataSource dataSource;

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("application/json"); // Response mime type

        String xtitle = request.getParameter("title");
        String xyear = request.getParameter("year");
        String xdirector = request.getParameter("director");
        String xstar = request.getParameter("star");
        String sortby = request.getParameter("sortby");
        String sorttype = "";
		//if(sortby.startsWith("t")) {sorttype = "title";} else{sorttype = "rating";};
        String searchterm = request.getParameter("searchfor");
        String limit = request.getParameter("limit");
		String offset = request.getParameter("offset");
        // Output stream to STDOUT
        PrintWriter out = response.getWriter();

        try {
            // Get a connection from dataSource
            Connection dbcon = dataSource.getConnection();

            // Declare our statement
            Statement statement = dbcon.createStatement();

            String query = "SELECT m.id, m.title, m.year, m.director, group_concat(distinct g.name order by g.name) as genre, "
            		+ "group_concat(distinct s.name) as star, r.rating, group_concat(distinct s.id order by s.name) as starId "
            		; 
            
            String from = "FROM movies m, genres g, ratings r, genres_in_movies gm, stars_in_movies sm";
            String where = "WHERE m.id = gm.movieId and m.id = r.movieId and m.id = sm.movieId and g.id = gm.genreId and s.id = "
            		+ "sm.starId ";
            
            //if (sortby == "title") {
            //	from += ", stars s ";
            //	where += "and m.title like %" + searchterm + "% ";
            //}
            //if (sortby == "year") {
            //	from += ", stars s ";
            //	where += "and m.year like %" + searchterm + "% ";
            //}
            //if (sortby == "director") {
            //	from += ", stars s ";
            //	where += "and m.director like %" + searchterm + "% ";
            //}
            //if (sortby == "stars") {
            //	from += ", (SELECT s.id, s.name from stars as s, stars_in_movies as sim, movies as m where m.id = sim.movieId and sim.starId = s.id and" 
            //			+ " s.name like %" + searchterm + "%) as s ";
            //} 
            query += from;
            query += where;
            query += "group by m.id, r.rating ";
            query += "order by " + sorttype + " " + sortby + " limit " + limit + " offset " + offset + ";";
            
            
            // Perform the query
            ResultSet rs = statement.executeQuery(query);

            JsonArray jsonArray = new JsonArray();

            // Iterate through each row of rs
            while (rs.next()) {
                String movie_id = rs.getString("id");
                String movie_name = rs.getString("title");
                String movie_year = rs.getString("year");
                String movie_director = rs.getString("director");
                String genre_name = rs.getString("genre");
                String star_name = rs.getString("star");
                String rating = rs.getString("rating");
                String star_id = rs.getString("starId");

                // Create a JsonObject based on the data we retrieve from rs
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("movie_id", movie_id);
                jsonObject.addProperty("movie_name", movie_name);
                jsonObject.addProperty("movie_year", movie_year);
                jsonObject.addProperty("director", movie_director);
                jsonObject.addProperty("genre_name", genre_name);
                jsonObject.addProperty("star_name", star_name);
                jsonObject.addProperty("rating", rating);
                jsonObject.addProperty("star_id", star_id);
                
                jsonArray.add(jsonObject);
            }
            
            // write JSON string to output
            out.write(jsonArray.toString());
            // set response status to 200 (OK)
            response.setStatus(200);

            rs.close();
            statement.close();
            dbcon.close();
        } catch (Exception e) {
        	
			// write error message JSON object to output
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("errorMessage", e.getMessage());
			out.write(jsonObject.toString());

			// set reponse status to 500 (Internal Server Error)
			response.setStatus(500);

        }
        out.close();

    }
}
