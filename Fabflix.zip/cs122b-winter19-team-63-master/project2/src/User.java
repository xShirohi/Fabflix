import java.util.HashMap;
import java.util.Set;

/**
 * This User class only has the username field in this example.
 * You can add more attributes such as the user's shopping cart items.
 */
public class User {

    private final String userid;	
    public HashMap<String, Integer> scart;

    public User(String userid) {
        this.userid = userid;
        this.scart = new HashMap<>();
    }

    public String getUserid() { return this.userid; }
    
    public void addItem(String item) {
    	if (!scart.containsKey(item))
    		scart.put(item, 1);
    	else {
    		int count = scart.get(item);
    		scart.put(item, count);
    	};
    }
    
    public boolean containsItem(String item) {
    	if (!scart.containsKey(item))
    		return false;
    	return true;
    }
    
    public boolean removeItem(String item) {
    	if (containsItem(item)) {
    		scart.remove(item);
    		return true;
    	}
    	return false;
    }
    
    public Set<HashMap.Entry<String,Integer>> allItems(){
    	return scart.entrySet();
    }
}
