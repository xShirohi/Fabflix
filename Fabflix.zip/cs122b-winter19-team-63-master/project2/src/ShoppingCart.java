import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

/**
 * Servlet implementation class ShoppingCart
 */
@WebServlet(name = "ShoppingCart", urlPatterns = "/api/shoppingcart")
public class ShoppingCart extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
    // Create a dataSource which registered in web.xml
    @Resource(name = "jdbc/moviedb")
    private DataSource dataSource;
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String add = request.getParameter("add");
        String remove = request.getParameter("remove");
        String checkout = request.getParameter("checkout");
        String ccid = request.getParameter("ccid");
        String fname = request.getParameter("fname");
        String lname = request.getParameter("lname");
        String exp = request.getParameter("exp");
        String id = ((User) request.getSession().getAttribute("user")).getUserid();
        java.util.Date d = new java.util.Date();
        String date = new SimpleDateFormat("yyyy-MM-dd").format(d);
        String checkedout = "f";

		boolean successful = true;
        
        if (add != "")
        	((User) request.getSession().getAttribute("user")).addItem(add);
        if (remove != "") {
        	successful = ((User) request.getSession().getAttribute("user")).removeItem(remove);
        }
		
		response.setContentType("application/json");
		
		if (checkout != "") {
	        PrintWriter out = response.getWriter();
	        try {
	            // Get a connection from dataSource
	            Connection dbcon = dataSource.getConnection();
	
	            // Declare our statement
	            Statement statement = dbcon.createStatement();
	
	            String query = "SELECT count(*) where exists (select * from creditcards as c where c.id = " + ccid + " and c.firstName = "
	            		+ fname + " and c.lastName = " + lname + " and c.expiration = " + exp;          		; 
	  
	            // Perform the query
	            ResultSet rs = statement.executeQuery(query);
	            String count = rs.getString("count");
	            
	            if (count != "0") {
	            	Set<HashMap.Entry<String,Integer>> total = ((User) request.getSession().getAttribute("user")).allItems();
	            	for (Entry<String, Integer> entry : total) {
	            		for (int x = 0; x < ((int) entry.getValue()); x++) {
	            			String query2 = "insert into sales values (NULL, \"" + id + "\", \"" + entry.getKey() + "\", \'" +
	            		 date + "\');";
	            			statement.executeQuery(query2);
	            		}
	            	}
	            	checkedout = "t";
	            }
	            
	            JsonArray jsonArray = new JsonArray();
	
	            // Iterate through each row of rs
                // Create a JsonObject based on the data we retrieve from rs
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("removed", successful);
                jsonObject.addProperty("checkedout", checkedout);
                jsonArray.add(jsonObject);

	            
	            // write JSON string to output
	            out.write(jsonArray.toString());
	            // set response status to 200 (OK)
	            response.setStatus(200);
	
	            rs.close();
	            statement.close();
	            dbcon.close();
	        } catch (Exception e) {
	        	
				// write error message JSON object to output
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("errorMessage", e.getMessage());
				out.write(jsonObject.toString());
	
				// set reponse status to 500 (Internal Server Error)
				response.setStatus(500);
	
	        }
	        out.close();
		}
		else {
			PrintWriter out = response.getWriter();
            JsonArray jsonArray = new JsonArray();

			JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("removed", successful);
            jsonObject.addProperty("checkedout", checkedout);
            jsonArray.add(jsonObject);

            
            // write JSON string to output
            out.write(jsonArray.toString());
		}
		


	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
