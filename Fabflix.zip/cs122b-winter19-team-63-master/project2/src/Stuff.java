import java.util.ArrayList;

public class Stuff {
	String Director_name;
	String Movie_name;
	ArrayList<String> Movie_id;
	ArrayList<String> Genres;
	String Star_name;
	String Birth_year;
	String Movie_year;
	String Actor_id;
	
	public Stuff() {
		this.Director_name = "";
		this.Movie_name = "";
		this.Movie_id = new ArrayList<String>();
		this.Genres = new ArrayList<String>();
		this.Star_name = "";
		this.Birth_year = "";
		this.Movie_year = "";
		this.Actor_id = "";
	}
	
	public String printStuff() {
		StringBuffer sb = new StringBuffer();
		sb.append(Director_name + " ");
		sb.append(Movie_name+ " ");
		for (String t : Movie_id)
			sb.append(t + " ");
		sb.append(Star_name+ " ");
		sb.append(Birth_year+ " ");
		sb.append(Movie_year+ " ");
		for (String temp : Genres)
			sb.append(temp+ " ");
		sb.append("\n");
		return sb.toString();
	}
	
}
