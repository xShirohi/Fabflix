/**
 * This example is following front end and back end separation.
 *
 * Before this .js is loaded, the html skeleton is created.
 *
 * This .js performs two steps:
 *      1. Use jQuery to talk to backend API to get the json data.
 *      2. Populate the data to correct html elements.
 */


/**
 * Handles the data returned by the API, read the jsonObject and populate data into html elements
 * @param resultData jsonObject
 */
var offset =0;
var current_page= 0;
var pagelist = new Array();
var numbers_per_page =20;

function nextPage(){
	$("#movie_table_body").empty();
	pagelist.push(offset);
	jQuery.ajax({
	    dataType: "json", // Setting return data type
	    method: "GET", // Setting request method
	    url: "api/movies?offset=" + pagelist[current_page], // Setting request url, which is mapped by MoviesServlet in Movies.java
	    success: (resultData) => handleMovieResult(resultData) // Setting callback function to handle data returned successfully by the MoviesServlet
	});
	current_page += 1;
}

function prevPage(){
	$("#movie_table_body").empty();
	if (current_page > 0)
		current_page -= 1;
	jQuery.ajax({
	    dataType: "json", // Setting return data type
	    method: "GET", // Setting request method
	    url: "api/movies?offset=" + pagelist[current_page], // Setting request url, which is mapped by MoviesServlet in Movies.java
	    success: (resultData) => handleMovieResult(resultData) // Setting callback function to handle data returned successfully by the MoviesServlet
	});
	if (current_page > 0)
		pagelist.pop();
}


function handleMovieResult(resultData) {
    console.log("handleMovieResult: populating movie table from resultData");

    // Populate the movie table
    // Find the empty table body by id "movie_table_body"
    let movieTableBodyElement = jQuery("#movie_table_body");
    var cur;
    var x = 0;
    var placehold;
    var genre_check = [];
    var star_check = [];


    // Iterate through resultData, no more than 10 entries
    for (let i = 0; i < Math.min(numbers_per_page, resultData.length); i++) {
    	cur = resultData[x]["movie_id"];
        // Concatenate the html tags with resultData jsonObject
        let rowHTML = "";
        rowHTML += "<tr>";
        rowHTML +=
			"<th>" +
			// Add a link to single-movie.html with id passed with GET url parameter
			'<a href="single-movie.html?id=' + resultData[x]['movie_id'] + '">'
			+ resultData[x]["movie_name"] +     // display movie_name for the link text
			'</a>' +
			"</th>";
    	rowHTML += "<th>" + resultData[x]["movie_year"] + "</th>";
    	rowHTML += "<th>" + resultData[x]["director"] + "</th>";
    	rowHTML += "<th>" + resultData[x]["rating"] + "</th>";
    	
        rowHTML += "<th>";
        placehold = "<th>";

        var genre_check = [];
        var star_check = [];
        while(cur == resultData[x]["movie_id"]){ 
        	if (!genre_check.includes(resultData[x]["genre_name"])){
        		rowHTML += resultData[x]["genre_name"] + "\n";
        		genre_check.push(resultData[x]["genre_name"]);
        	}
        	if (!star_check.includes(resultData[x]["star_name"])){
        		placehold += // Add a link to single-movie.html with id passed with GET url parameter
        			'<a href="single-star.html?id=' + resultData[x]['star_id'] + '">'
        			+ resultData[x]["star_name"] +     // display movie_name for the link text
        			'</a>' + ", ";
        		star_check.push(resultData[x]["star_name"]);
        	}
        	x++;
        }

        rowHTML += "</th>";
        rowHTML += placehold.substr(0, placehold.length -2) + "</th>";
        
        rowHTML += "</tr>";

        // Append the row created to the table body, which will refresh the page
        movieTableBodyElement.append(rowHTML);
    }
    offset += x;
}


/**
 * Once this .js is loaded, following scripts will be executed by the browser
 */

// Makes the HTTP GET request and registers on success callback function handleMovieResult
jQuery.ajax({
    dataType: "json", // Setting return data type
    method: "GET", // Setting request method
    url: "api/movies?offset=" + offset, // Setting request url, which is mapped by MoviesServlet in Movies.java
    success: (resultData) => handleMovieResult(resultData) // Setting callback function to handle data returned successfully by the MoviesServlet
});