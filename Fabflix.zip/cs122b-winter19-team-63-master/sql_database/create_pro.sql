DELIMITER //
CREATE PROCEDURE add_star(IN name varchar(100), IN birthYear integer)
BEGIN
SET @maxID = 0;
SELECT CONVERT(SUBSTRING(MAX(id), 3), unsigned integer) into @maxID from stars;
SET @maxID = @maxID + 1;
SET @maxID = CONCAT('nm', @maxID);
IF birthYear IS NULL THEN
INSERT INTO stars(id, name) VALUES(@maxID, name);
ELSE
INSERT INTO stars(id, name, birthYear) VALUES(@maxID, name, birthYear); 
END IF;
END//
DELIMITER ;



DELIMITER //
CREATE PROCEDURE add_genre(IN name varchar(32))
BEGIN
SET @maxID = 0;
SELECT MAX(id) into @maxID from genres;
SET @maxID = @maxID + 1;
INSERT INTO genres(id, name) VALUES(@maxID, name);
END //
DELIMITER ;



DELIMITER //
CREATE PROCEDURE add_movie(IN title varchar(100), IN year integer, IN director varchar(100), IN star varchar(100), IN genre varchar(32))
BEGIN
set @starID = "";
set @movieID = 0;
set @genreID = 0;
IF (SELECT id FROM stars where name = star) IS NULL THEN
CALL add_star(star, null);
END IF;
IF (SELECT id FROM genres where name = genre) IS NULL THEN
CALL add_genre(genre);
END IF;
SELECT id into @starID FROM stars where name = star limit 1;
SELECT id into @genreID FROM genres where name = genre limit 1;
SELECT CONVERT(SUBSTRING(MAX(id), 3), unsigned integer) into @movieID from movies;
SET @movieID = @movieID + 1;
SET @movieID = CONCAT('tt', @movieID);
INSERT INTO movies(id, title, year, director) VALUES(@movieID, title, year, director);
INSERT INTO stars_in_movies(starId, movieId) VALUES(@starID, @movieID);
INSERT INTO genres_in_movies(genreId, movieId) VALUES(@genreID, @movieID);
INSERT INTO ratings(movieId, rating, numVotes) VALUES(@movieID, 0, 0);
END //
DELIMITER ;

CREATE FULLTEXT INDEX movie_title ON movies(title);
