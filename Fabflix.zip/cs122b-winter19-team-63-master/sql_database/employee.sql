use moviedb;
CREATE TABLE employees(
	email varchar(50),
	password varchar(20) NOT NULL,
	fullname varchar(100),
	PRIMARY KEY(email)
);

INSERT INTO employees(email, password, fullname) VALUES('classta@email.edu', 'classta', 'TA CS122B');
