DROP DATABASE IF EXISTS moviedb;
CREATE DATABASE moviedb;
USE moviedb;

CREATE Table movies(
    id varchar(10),
    title varchar(100) not null,
    year integer not null,
    director varchar(100) not null,
    PRIMARY KEY(id)
);

CREATE Table stars(
    id varchar(10),
    name varchar(100) not null,
    birthYear integer,
    PRIMARY KEY(id)
);

CREATE Table stars_in_movies(
    starId varchar(10) not null,
    movieId varchar(10) not null,
    FOREIGN KEY(starId) REFERENCES stars(id) ON DELETE CASCADE,
    FOREIGN KEY(movieId) REFERENCES movies(id) ON DELETE CASCADE
);

CREATE Table genres(
    id integer AUTO_INCREMENT,
    name varchar(32) not null,
    PRIMARY KEY(id)
);

CREATE Table genres_in_movies(
    genreId integer not null,
    movieId varchar(10) not null,
    FOREIGN KEY(genreId) REFERENCES genres(id) ON DELETE CASCADE,
    FOREIGN KEY(movieId) REFERENCES movies(id) ON DELETE CASCADE
);

CREATE Table creditcards(
    id varchar(20),
    firstName varchar(50) not null,
    lastName varchar(50) not null,
    expiration date not null,
    PRIMARY KEY(id)
);

CREATE Table customers(
    id integer AUTO_INCREMENT,
    firstName varchar(50) not null,
    lastName varchar(50) not null,
    ccId varchar(20) not null,
    address varchar(200) not null,
    email varchar(50) not null,
    password varchar(20) not null,
    PRIMARY KEY(id),
    FOREIGN KEY(ccId) REFERENCES creditcards(id) ON DELETE CASCADE
);

CREATE Table sales(
    id integer AUTO_INCREMENT,
    customerId integer not null,
    movieId varchar(10) not null,
    saleDate date not null,
    PRIMARY KEY(id),
    FOREIGN KEY(customerId) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY(movieId) REFERENCES movies(id) ON DELETE CASCADE
);

CREATE Table ratings(
    movieId varchar(10) not null,
    rating float not null,
    numVotes integer not null,
    FOREIGN KEY(movieId) REFERENCES movies(id) ON DELETE CASCADE
);


