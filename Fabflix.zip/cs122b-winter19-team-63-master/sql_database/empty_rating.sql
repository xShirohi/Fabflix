use moviedb;
ALTER TABLE ratings
ALTER COLUMN rating SET DEFAULT 0;

ALTER TABLE ratings
ALTER COLUMN numVotes SET DEFAULT 0;

INSERT INTO ratings(movieId) select id from movies where not exists (select movieId from ratings where movieId = id);
