	import com.google.gson.JsonArray;
	import com.google.gson.JsonObject;
	
	import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.sql.DataSource;
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.sql.Connection;
	import java.sql.ResultSet;
	import java.sql.Statement;
	import java.sql.PreparedStatement;
	;
	
	// Declaring a WebServlet called MovieServlet, which maps to url "/api/movies"
	@WebServlet(name = "MovieServlet", urlPatterns = "/api/movies")
	public class MovieServlet extends HttpServlet {
	    private static final long serialVersionUID = 1L;
	
	    // Create a dataSource which registered in web.xml
//	    @Resource(name = "jdbc/moviedb")
//	    private DataSource dataSource;
	
	    /**
	     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	     */
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	        response.setContentType("application/json"); // Response mime type
	
	        String xtitle = request.getParameter("title");
	        String xyear = request.getParameter("year");
	        String xdirector = request.getParameter("director");
	        String xstar = request.getParameter("star");
	        String sortby = request.getParameter("sortby");
	                if (sortby == null)
	        	sortby = "tasc";
	        String sorttype = "";
			if(sortby.startsWith("t")) 
				sorttype = "m.title"; 
			else
				sorttype = "r.rating";
			sortby = sortby.substring(1);
	        String searchterm = request.getParameter("searchfor");
	        String limit = request.getParameter("limit");
	        if (limit == null)
	        	limit = "20";
			String offset = request.getParameter("offset");
			if (offset == null)
				offset = "0";
	//		
			System.out.println(xtitle + "?????");
			if (xtitle == "true")
				System.out.println("!!!!");
	        // Output stream to STDOUT
	        PrintWriter out = response.getWriter();
	        System.out.println(xtitle + " zxcv " + xyear + " zxcv " + xdirector + " zxcv " + xstar + " sortby " + sortby + " search " + searchterm);
	
	        try {
	            // the following few lines are for connection pooling
	            // Obtain our environment naming context

	            Context initCtx = new InitialContext();

	            Context envCtx = (Context) initCtx.lookup("java:comp/env");
	            if (envCtx == null)
	                System.out.println("envCtx is NULL");

	            // Look up our data source
	            DataSource ds = (DataSource) envCtx.lookup("jdbc/TestDB");

	            // the following commented lines are direct connections without pooling
	            //Class.forName("org.gjt.mm.mysql.Driver");
	            //Class.forName("com.mysql.jdbc.Driver").newInstance();
	            //Connection dbcon = DriverManager.getConnection(loginUrl, loginUser, loginPasswd);

	            if (ds == null)
	                System.out.println("ds is null.");

	            Connection dbcon = ds.getConnection();
	            if (dbcon == null)
	                System.out.println("dbcon is null.");
	            dbcon.setReadOnly(true);

	            // Get a connection from dataSource
	            //Connection dbcon = dataSource.getConnection();
	
	            // Declare our statement
	            
	
	            
	            String query = "SELECT m.id, m.title, m.year, m.director, group_concat(distinct g.name order by g.name) as genre,"+
	            			   "group_concat(distinct s.name) as star, r.rating, group_concat(distinct sm.starId) as starId ";//like \"%the%\"  
	            		
	            
	            String from = "FROM movies m, genres g, ratings r, genres_in_movies gm, stars_in_movies sm ";
	            String where = "WHERE m.id = gm.movieId and m.id = r.movieId and m.id = sm.movieId and g.id = gm.genreId and s.id = sm.starId ";
	            if (xtitle.equals("true")) {
	            	from += ", stars s ";
	            	where += "and m.title like ? ";
	            }
	            else if (xyear.equals("true")) {
	            	from += ", stars s ";
	            	where += "and m.year like ? ";
	            }
	            else if (xdirector.equals("true")) {
	            	from += ", stars s ";
	            	where += "and m.director like ? ";
	            }
	            else if (xstar.equals("true")) {
	            	from += ", (SELECT s.id, s.name from stars as s, stars_in_movies as sim, movies as m where m.id = sim.movieId and sim.starId = s.id and" 
	            			+ " s.name like ?) as s ";
	            } 
	            else
	            	from += ", stars s ";
	            query += from;
	            query += where;
	            query += "group by m.id, r.rating order by " + sorttype + " " + sortby + " limit " + limit + " offset " + offset + ";";
	            //out.print(query);
	            System.out.println(query);
	            PreparedStatement ps = dbcon.prepareStatement(query);
	            if (xtitle.equals("true") || xyear.equals("true")|| xdirector.equals("true")|| xstar.equals("true")) {
	            	ps.setString(1, "%" + searchterm + "%");
	            	System.out.println(searchterm + " to be serachedesfsefsefes");
	            }
	            System.out.println(query);
	            // Perform the query
	            ResultSet rs = ps.executeQuery();
	
	            JsonArray jsonArray = new JsonArray();
	
	            // Iterate through each row of rs
	            while (rs.next()) {
	                String movie_id = rs.getString("id");
	                String movie_name = rs.getString("title");
	                String movie_year = rs.getString("year");
	                String movie_director = rs.getString("director");
	                String genre_name = rs.getString("genre");
	                String star_name = rs.getString("star");
	                String rating = rs.getString("rating");
	                String star_id = rs.getString("starId");
	
	                // Create a JsonObject based on the data we retrieve from rs
	                JsonObject jsonObject = new JsonObject();
	                jsonObject.addProperty("movie_id", movie_id);
	                jsonObject.addProperty("movie_name", movie_name);
	                jsonObject.addProperty("movie_year", movie_year);
	                jsonObject.addProperty("director", movie_director);
	                jsonObject.addProperty("genre_name", genre_name);
	                jsonObject.addProperty("star_name", star_name);
	                jsonObject.addProperty("rating", rating);
	                jsonObject.addProperty("star_id", star_id);
	                
	                jsonArray.add(jsonObject);
	            }
	            
	            // write JSON string to output
	            out.write(jsonArray.toString());
	            // set response status to 200 (OK)
	            response.setStatus(200);
	
	            rs.close();
	            ps.close();
	            dbcon.close();
	        } catch (Exception e) {
	        	
				// write error message JSON object to output
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("errorMessage", e.getMessage());
				out.write(jsonObject.toString());
	
				// set reponse status to 500 (Internal Server Error)
				response.setStatus(500);
	
	        }
	        out.close();
	
	    }
	}