import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

// Declaring a WebServlet called SingleMovieServlet, which maps to url "/api/single-movie"
@WebServlet(name = "BrowseGenre", urlPatterns = "/api/browse-genre")
public class BrowseGenre extends HttpServlet {
	private static final long serialVersionUID = 2L;

	// Create a dataSource which registered in web.xml
//	@Resource(name = "jdbc/moviedb")
//	private DataSource dataSource;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("application/json"); // Response mime type

		// Retrieve parameter id from url request.
		String genre = request.getParameter("genre");
		String page = request.getParameter("page");
		String limit = request.getParameter("limit");
		String offset = request.getParameter("offset");
		//calculate offset based on N listings x page number 
		int offNum = Integer.parseInt(limit) * Integer.parseInt(page);
		offNum = offNum - Integer.parseInt(limit);
		offset = String.valueOf(offNum);
		//figure out if sort is by title or rating 
		String sortby = request.getParameter("sortby");
		String sorttype = "";
		if(sortby.startsWith("t")) {sorttype = "title";} else{sorttype = "rating";};
		sortby = sortby.substring(1);

		// Output stream to STDOUT
		PrintWriter out = response.getWriter();

		try {
			
            // the following few lines are for connection pooling
            // Obtain our environment naming context

            Context initCtx = new InitialContext();

            Context envCtx = (Context) initCtx.lookup("java:comp/env");
            if (envCtx == null)
                System.out.println("envCtx is NULL");

            // Look up our data source
            DataSource ds = (DataSource) envCtx.lookup("jdbc/TestDB");

            // the following commented lines are direct connections without pooling
            //Class.forName("org.gjt.mm.mysql.Driver");
            //Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Connection dbcon = DriverManager.getConnection(loginUrl, loginUser, loginPasswd);

            if (ds == null)
                System.out.println("ds is null.");

            Connection dbcon = ds.getConnection();
            if (dbcon == null)
                System.out.println("dbcon is null.");
            dbcon.setReadOnly(true);

			// Get a connection from dataSource
			//Connection dbcon = dataSource.getConnection();
			String query = "";
			PreparedStatement statement = dbcon.prepareStatement(query);
			// Construct a query with parameter represented by "?"
			if(sorttype.equals("name") || sorttype.equals("rating")) {
				if(sortby.equals("desc") || sortby.equals("asc")) {
					query = "SELECT * FROM ("
							+ "SELECT m.id, m.title, m.year, m.director, "
							+ "group_concat(distinct g.name order by g.name) as genre, "
							+ "group_concat(distinct s.name order by s.name) as star, "
							+ "group_concat(distinct s.id order by s.name) as star_ids, "
							+ "r.rating "
							+ "FROM movies m, genres g, stars s, ratings r, "
							+ "genres_in_movies gm, stars_in_movies sm "
							+ "WHERE m.id = gm.movieId and m.id = r.movieId "
							+ "and m.id = sm.movieId and g.id = gm.genreId "
							+ "and s.id = sm.starId group by m.id, r.rating"
							+ ") as temp "
							+ "WHERE temp.genre like ? "
							+ "order by temp." + sorttype + " " + sortby + " limit ? offset ?;";
					statement = dbcon.prepareStatement(query);
					statement.setString(1, "%" + genre + "%");
					statement.setInt(2, Integer.parseInt(limit));
					statement.setInt(3, Integer.parseInt(offset));
					System.out.println(statement.toString());
				}
			}
			// Declare our statement

			// Perform the query
			ResultSet rs = statement.executeQuery();

			JsonArray jsonArray = new JsonArray();

			// Iterate through each row of rs
			while (rs.next()) {
				String movie_id = rs.getString("id");
                String movie_name = rs.getString("title");
                String movie_year = rs.getString("year");
                String movie_director = rs.getString("director");
                String genre_names = rs.getString("genre");
                String star_names = rs.getString("star");
                String star_ids = rs.getString("star_ids");
                String rating = rs.getString("rating");

                // Create a JsonObject based on the data we retrieve from rs
                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("movie_id", movie_id);
                jsonObject.addProperty("movie_name", movie_name);
                jsonObject.addProperty("movie_year", movie_year);
                jsonObject.addProperty("director", movie_director);
                jsonObject.addProperty("genre_name", genre_names);
                jsonObject.addProperty("star_name", star_names);
                jsonObject.addProperty("star_ids", star_ids);
                jsonObject.addProperty("rating", rating);

				jsonArray.add(jsonObject);
			}
			
            // write JSON string to output
            out.write(jsonArray.toString());
            // set response status to 200 (OK)
            response.setStatus(200);

			rs.close();
			statement.close();
			dbcon.close();
		} catch (Exception e) {
			// write error message JSON object to output
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("errorMessage", e.getMessage());
			out.write(jsonObject.toString());

			// set response status to 500 (Internal Server Error)
			response.setStatus(500);
		}
		out.close();

	}

}
