import com.google.gson.JsonObject;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.annotation.Resource;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.jasypt.util.password.StrongPasswordEncryptor;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * This class is declared as LoginServlet in web annotation, 
 * which is mapped to the URL pattern /api/login
 */
@WebServlet(name = "LoginServlet", urlPatterns = "/api/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
//    public String getServletInfo() {
//        return "Servlet connects to MySQL database and displays result of a SELECT";
//    }
    
    // Create a dataSource which registered in web.xml
    //@Resource(name = "jdbc/moviedb")
    //private DataSource dataSource;

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String userAgent = request.getHeader("User-Agent");
        String query_user = "";
        String query_pw = "";
        String userid = "";
        boolean success = false;
        
        //response.setContentType("application/json"); // Response mime type
        try {
        	
            // the following few lines are for connection pooling
            // Obtain our environment naming context

            Context initCtx = new InitialContext();

            Context envCtx = (Context) initCtx.lookup("java:comp/env");
            if (envCtx == null)
                System.out.println("envCtx is NULL");

            // Look up our data source
            DataSource ds = (DataSource) envCtx.lookup("jdbc/TestDB");

            // the following commented lines are direct connections without pooling
            //Class.forName("org.gjt.mm.mysql.Driver");
            //Class.forName("com.mysql.jdbc.Driver").newInstance();
            //Connection dbcon = DriverManager.getConnection(loginUrl, loginUser, loginPasswd);

            if (ds == null)
                System.out.println("ds is null.");

            Connection dbcon = ds.getConnection();
            if (dbcon == null)
                System.out.println("dbcon is null.");	
        // Get a connection from dataSource
        //Connection dbcon = dataSource.getConnection();

        // Declare our statement
        

        String query = "SELECT c.email as user, c.password as pw, c.id as id "
        		+ "FROM customers c "
        		+ "WHERE c.email = ?;";
        
        PreparedStatement statement = dbcon.prepareStatement(query);
        statement.setString(1, username);

        // Perform the query
        ResultSet rs = statement.executeQuery();
        
        while(rs.next()) {
        	System.out.println("Query worked.");
        	query_user = rs.getString("user");
        	query_pw = rs.getString("pw");
        	userid = rs.getString("id");
        }
        

        // set response status to 200 (OK)
        //response.setStatus(200);

        rs.close();
        statement.close();
        dbcon.close();
        } catch (Exception e) {
        	
			// write error message JSON object to output
			JsonObject jsonObject = new JsonObject();
			jsonObject.addProperty("errorMessage", e.getMessage());

			// set reponse status to 500 (Internal Server Error)
			//response.setStatus(500);

        }

        /**
         * This example only allows username/password to be anteater/123456
         * In real world projects, you should talk to the database to verify username/password
         */
        if (userAgent != null && !userAgent.contains("Android")) {
	        // Verify reCAPTCHA
	        String gRecaptchaResponse = request.getParameter("g-recaptcha-response");
	        try {
	            RecaptchaVerifyUtils.verify(gRecaptchaResponse);
	        } catch (Exception e) {
	            JsonObject responseJsonObject = new JsonObject();
	            responseJsonObject.addProperty("status", "fail");
	            responseJsonObject.addProperty("message", "Verification failed.");
	            response.getWriter().write(responseJsonObject.toString());
	            return;
	        }
	        success = false;
        }
        if(!query_user.isEmpty() && !query_pw.isEmpty()) {
        	success = new StrongPasswordEncryptor().checkPassword(password, query_pw);
        }
        
        if (query_user.equals(username) && success) {
            // Login succeeds
            // Set this user into current session
            String sessionId = ((HttpServletRequest) request).getSession().getId();
            Long lastAccessTime = ((HttpServletRequest) request).getSession().getLastAccessedTime();
            request.getSession().setAttribute("user", new User(userid));
            /*if(request.getSession().getAttribute("employee") != null) {
            	request.getSession().removeAttribute("employee");
            }*/

            JsonObject responseJsonObject = new JsonObject();
            responseJsonObject.addProperty("status", "success");
            responseJsonObject.addProperty("message", "success");

            response.getWriter().write(responseJsonObject.toString());
        } else {
            // Login fails
            JsonObject responseJsonObject = new JsonObject();
            responseJsonObject.addProperty("status", "fail");
            if (!query_user.equals(username)) {
                responseJsonObject.addProperty("message", "user " + username + " doesn't exist");
            } else {
                responseJsonObject.addProperty("message", "incorrect password");
            }
            response.getWriter().write(responseJsonObject.toString());
        }
    }
}
