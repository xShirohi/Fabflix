	import com.google.gson.JsonArray;
	import com.google.gson.JsonObject;
	
	import javax.annotation.Resource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import javax.sql.DataSource;
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.sql.Connection;
	import java.sql.ResultSet;
	import java.sql.PreparedStatement;
	;
	
	// Declaring a WebServlet called MovieServlet, which maps to url "/api/movies"
	@WebServlet(name = "MovieSuggestion", urlPatterns = "/api/movie_suggestion")
	public class MovieSuggestion extends HttpServlet {
	    private static final long serialVersionUID = 1L;
	
	    // Create a dataSource which registered in web.xml
//	    @Resource(name = "jdbc/moviedb")
//	    private DataSource dataSource;
	
	    /**
	     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	     */
	    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	        response.setContentType("application/json"); // Response mime type
	
	        String title = request.getParameter("query");
	        String words[] = title.split(" ", 0);
	        String title_query = "";
	        for(String word: words) {
	        	title_query += "+" + word + "* ";
	        }
	        title_query = title_query.substring(0, title_query.length() - 1);
	        System.out.println(title_query);
	        PrintWriter out = response.getWriter();
	        try {
	            // the following few lines are for connection pooling
	            // Obtain our environment naming context

	            Context initCtx = new InitialContext();

	            Context envCtx = (Context) initCtx.lookup("java:comp/env");
	            if (envCtx == null)
	                System.out.println("envCtx is NULL");

	            // Look up our data source
	            DataSource ds = (DataSource) envCtx.lookup("jdbc/TestDB");

	            // the following commented lines are direct connections without pooling
	            //Class.forName("org.gjt.mm.mysql.Driver");
	            //Class.forName("com.mysql.jdbc.Driver").newInstance();
	            //Connection dbcon = DriverManager.getConnection(loginUrl, loginUser, loginPasswd);

	            if (ds == null)
	                System.out.println("ds is null.");

	            Connection dbcon = ds.getConnection();
	            if (dbcon == null)
	                System.out.println("dbcon is null.");
	            dbcon.setReadOnly(true);

	            // Get a connection from dataSource
	            //Connection dbcon = dataSource.getConnection();
	
	            // Declare our statement
	            String query = "SELECT * FROM movies WHERE MATCH (title) AGAINST (? "
	            		+ "IN BOOLEAN MODE);";
	      
	            PreparedStatement ps = dbcon.prepareStatement(query);
	            ps.setString(1, title_query);
	            System.out.println("reach here " + ps.toString());
	            // Perform the query
	            ResultSet rs = ps.executeQuery();
	
	            JsonArray jsonArray = new JsonArray();
	            int limit = 0;
	            // Iterate through each row of rs
	            //"value": "Superman", "data": { "heroID": 101 } }
	            while (rs.next()) {
	            	if(limit == 10) {break;}
	                String movie_id = rs.getString("id");
	                String movie_name = rs.getString("title");
	
	                // Create a JsonObject based on the data we retrieve from rs
	                JsonObject jsonObject = new JsonObject();
	                jsonObject.addProperty("value", movie_name);
	                
	                JsonObject additionalDataJsonObject = new JsonObject();
	                additionalDataJsonObject.addProperty("movie_id", movie_id);
	                
	                jsonObject.add("data", additionalDataJsonObject);
	                jsonArray.add(jsonObject);
	                ++limit;
	            }
	            
	            // write JSON string to output
	            out.write(jsonArray.toString());
	            // set response status to 200 (OK)
	            response.setStatus(200);
	
	            rs.close();
	            ps.close();
	            dbcon.close();
	        } catch (Exception e) {
	        	
				// write error message JSON object to output
				JsonObject jsonObject = new JsonObject();
				jsonObject.addProperty("errorMessage", e.getMessage());
				out.write(jsonObject.toString());
	
				// set reponse status to 500 (Internal Server Error)
				response.setStatus(500);
	
	        }
	        out.close();
	
	    }
	}